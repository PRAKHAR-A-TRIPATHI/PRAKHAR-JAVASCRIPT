let a = document.getElementById("Amount");
let b = document.getElementById("code");

let gst = 18;


let button = document.getElementById("btn");
button.addEventListener("click", ()=>{
    let amount = a.value ;
    let discount = b.value;
    let gstamount = amount + (amount*gst/100);
    let total = gstamount-(gstamount*discount/100);
    let amou = document.getElementById("amo");
    amou.innerText=total;
    // console.log(amount);
    // console.log(discount);
    // console.log(gst);
    // return total;
})