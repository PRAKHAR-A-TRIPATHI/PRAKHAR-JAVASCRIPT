function mul(a,b,c){
    return (a*b)*c;
}
 
console.log(mul((2),(3),(4)))
console.log(mul((4),(3),(4)))